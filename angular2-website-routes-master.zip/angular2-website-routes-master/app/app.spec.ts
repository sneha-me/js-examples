import { describe, it, expect } from '@angular/core/testing';

import { AppComponent } from './app.component';

describe('AppComponent', () => {
  it('should be a function', () => {
    expect(typeof AppComponent).toBe('function');
  });
});
