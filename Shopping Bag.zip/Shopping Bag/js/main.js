function ListBag(){}




$().ready(function(){
  var list_bag = new ListBag();
  list_bag.init();
})

ListBag.prototype.init = function(){
  //alert('hi')
  //var cartData = JSON.parse(productsInCart);
  $.getJSON("./cart.json", function(data) {
       console.log(":hi")
    });

}