function ListBag(){}




$().ready(function(){
  var list_bag = new ListBag();
  list_bag.init();
})

ListBag.prototype.init = function(){

  $.getJSON('./cart.json', function(data) {
       console.log(":hi")
       $('.size').html(data.productsInCart[0].size);
    for(i=0; i< data.productsInCart.length; i++){
      $("#shopping-table").append("<tr> <td>" +
          "<img src=../assets/T"+(i+1)+".jpg alt='T1 shirt' /></td>"+
          "<td>" + "<div class='summary'>" +
              "<h4>" + data.productsInCart[i].p_variation +data.productsInCart[i].p_name +"</h4>" +
              "<p> Style #: " +data.productsInCart[i].p_style + "</p>" +
              "<p>Colour : " + data.productsInCart[i].p_selected_color.name + "</p> </div> </td>" +
            
          "<td class='size'>" +data.productsInCart[i].p_selected_size['code']+ "</td>" +
          "<td class='qty'>" + data.productsInCart[i].p_quantity + "</td>" +
          "<td class='price'>" + data.productsInCart[i].c_currency + data.productsInCart[i].p_price + "</td> </tr>");
    }
    });
}
