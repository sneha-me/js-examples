import {Component} from '@angular/core';
@Component({
    selector: 'my-app',
    template: '<h2> My first Angular2 Appopopopopopo</h2>'
})
export class AppComponent{}